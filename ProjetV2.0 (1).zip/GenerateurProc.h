#ifndef _GENERATEUR_PROC_H
#define _GENERATEUR_PROC_H

#include "Utils.h"

int _fileProcEntrantsId;

void readFile();
void soumission();

#endif