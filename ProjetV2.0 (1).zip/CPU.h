#ifndef _CPU_H
#define _CPU_H

int _fileProcExecutionId;
int _fileProcEntrantsId;


void* start_cpu(void* pas);

#endif